# LFSPkg
Package manager for LFS/BLFS

Use in conjuction with the LFSPkg build scripts here:
https://github.com/KeithDHedger/LFSPkgBuilds